Speed tests for Diff, Match and Patch Library
http://code.google.com/p/google-diff-match-patch/
Google 2010

The contents of this archive are designed to be copied into the
diff-match-patch source tree.  Each test uses the same diff.
The diff is a real-world edit from Wikipedia, chosen because of
its complexity and variety.

Most languages perform the diff twice, once as a warmup for any
JIT compiler, with a garbage collection sweep in between.
This results in more consistent and accurate measurements.
