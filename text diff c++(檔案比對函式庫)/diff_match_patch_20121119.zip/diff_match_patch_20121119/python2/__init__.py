from .diff_match_patch import diff_match_patch, patch_obj

