
#ifndef DTL_EXAMPLE_COMMON_H
#define DTL_EXAMPLE_COMMON_H

#include <string>
#include <cstdio>

using namespace std;

bool isFileExist (string& fs);
bool isFewArgs (int argc, int limit = 3);

#endif
