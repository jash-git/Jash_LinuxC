OpenGL Tutorial #8.

Project Name: OpenGL Tutorial By Tom Stanis

Project Description: Blending In OpenGL

Authors Name: Tom Stanis / Jeff Molofee (aka NeHe)

Authors Web Site: www.hypercosm.com (Tom's)
                  nehe.gamedev.net (NeHe's)

COPYRIGHT AND DISCLAIMER: (c)2000 Jeff Molofee / Tom Stanis

	If you plan to put this program on your web page or a cdrom of
	any sort, let me know via email, I'm curious to see where
	it ends up :)

        If you use the code for your own projects please give us credit,
        or mention our web sites somewhere in your program or it's docs.

* Modified by NeHe Feb 2000
