OpenGL Tutorial #37.

Project Name: Cel-Shading

Project Description: How To Create Cartoon Renderings

Authors Name:	Sami Hamlaoui (MENTAL) / Jeff Molofee (NeHe)

Hosted Web Site: http://nehe.gamedev.net

COPYRIGHT AND DISCLAIMER: (c)2001 Jeff Molofee

       If you plan to put this program on your web page or a cdrom of
       any sort, let me know via email, I'm curious to see where
       it ends up :)

       If you use the code for your own projects please give the author credit,
       or mention his web site somewhere in your program or it's docs.
