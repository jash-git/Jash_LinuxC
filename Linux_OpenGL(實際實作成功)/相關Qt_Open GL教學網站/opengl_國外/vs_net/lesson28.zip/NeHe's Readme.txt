OpenGL Tutorial #28.

Project Name: David Nikdel & Jeff Molofee's OpenGL Bezier Tutorial

Project Description: Learn How To Create And Manipulate Textured Bezier Surfaces

Authors Name: David Nikdel

Authors Web Site: nehe.gamedev.net

COPYRIGHT AND DISCLAIMER: (c)2000 Jeff Molofee

	If you plan to put this program on your web page or a cdrom of
	any sort, let me know via email, I'm curious to see where
	it ends up :)

        If you use the code for your own projects please give the author credit.
