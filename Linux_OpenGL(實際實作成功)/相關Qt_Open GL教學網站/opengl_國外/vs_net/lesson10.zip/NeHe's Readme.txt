OpenGL Tutorial #10.

Project Name: OpenGL Tutorial By Lionel Brits

Project Description: Loading And Moving Through A 3D World

Authors Name: Lionel Brits / Jeff Molofee (aka NeHe)

Web Site: nehe.gamedev.net (NeHe Productions)

COPYRIGHT AND DISCLAIMER: (c)2000 Jeff Molofee

	If you plan to put this program on your web page or a cdrom of
	any sort, let me know via email, I'm curious to see where
	it ends up :)

        If you use the code for your own projects please give us credit,
        or mention our web sites somewhere in your program or it's docs.
