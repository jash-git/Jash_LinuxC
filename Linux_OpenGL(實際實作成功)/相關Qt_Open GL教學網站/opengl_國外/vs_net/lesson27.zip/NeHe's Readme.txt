OpenGL Tutorial #27.

Project Name: Banu Octavian & NeHe's Shadow Casting Tutorial

Project Description: Create Amazing Shadows That Cast Properly On Walls & Objects

Note:	CPU Usage While Inactive Has Been Reduced To About 1% In This Tutorial.

Authors Name: Jeff Molofee (aka NeHe)

Authors Web Site: nehe.gamedev.net

COPYRIGHT AND DISCLAIMER: (c)2000 Jeff Molofee

	If you plan to put this program on your web page or a cdrom of
	any sort, let me know via email, I'm curious to see where
	it ends up :)

       If you use the code for your own projects please give me credit,
       or mention my web site somewhere in your program or it's docs.
