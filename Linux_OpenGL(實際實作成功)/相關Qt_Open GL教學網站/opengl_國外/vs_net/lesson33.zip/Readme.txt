Thank you for downloading the example code for my TGA laoding tutorial.

While this code has been checked for bugs, i can not guarentee it will run, or be bugless on all computers, therefore i am not responsible for any damage other that may occur.  

Please send any bug fixes, questions, or comments to terminate@gdnmail.net.

Special thanks to:

	Nehe (nehe.gamedev.net) for his great tutorials (one of which has been modified forthis lesson)
	ShiningKnight for his help proofing and editing the tutorial

Evan "terminate" Pipho 