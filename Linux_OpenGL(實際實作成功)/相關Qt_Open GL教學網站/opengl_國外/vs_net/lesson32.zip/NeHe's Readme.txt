OpenGL Tutorial #32.

Project Name: Picking, Alpha Blending, Sorting, Alpha Testing.

Project Description:  A tiny game that teaches you about the above topics.

Authors Name: Jeff Molofee

NeHe Productions Web Site: nehe.gamedev.net

COPYRIGHT AND DISCLAIMER: (c)2001 Jeff Molofee

	If you plan to put this program on your web page or a cdrom of
	any sort, let me know via email, I'm curious to see where
	it ends up :)
