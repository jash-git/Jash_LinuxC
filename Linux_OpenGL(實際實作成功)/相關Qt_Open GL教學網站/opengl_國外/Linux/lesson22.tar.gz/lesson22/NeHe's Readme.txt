OpenGL Tutorial #22.

Project Name: OpenGL Tutorial By Jens Schneider

Project Description: Bump Mapping, Multi-Texturing & Extensions

Authors Name: Jens Schneider / Jeff Molofee (aka NeHe)

Web Site: nehe.gamedev.net (NeHe Productions)

COPYRIGHT AND DISCLAIMER: (c)2000 Jeff Molofee

	If you plan to put this program on your web page or a cdrom of
	any sort, let me know via email, I'm curious to see where
	it ends up :)

        If you use the code for your own projects please give us credit,
        or mention our web sites somewhere in your program or it's docs.
