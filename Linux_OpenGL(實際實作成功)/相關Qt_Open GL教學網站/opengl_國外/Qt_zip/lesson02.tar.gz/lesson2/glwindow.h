
#ifndef GLOBJWIN_H
#define GLOBJWIN_H

#include <qwidget.h>


class GlWindow : public QWidget
{
    Q_OBJECT
public:
    GlWindow( QWidget* parent = 0, const char* name = 0 );

};


#endif // GLOBJWIN_H
