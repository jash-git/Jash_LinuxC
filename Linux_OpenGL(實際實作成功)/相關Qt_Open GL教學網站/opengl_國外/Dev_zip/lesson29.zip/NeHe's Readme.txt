OpenGL Tutorial #29.

Project Name: Andreas L�ffler, Rob Fletcher & Jeff Molofee's OpenGL Blitter
              And RAW Image Loading Tutorial.

Project Description: Learn How To Blit Pieces Of One Texture Into Another Texture
                     You Can Blend The Textures Together And Stretch The Copied Texture
                     Load Raw Image Data.

Authors Name: Andreas L�ffler / Rob Fletcher

Authors Web Site: nehe.gamedev.net

COPYRIGHT AND DISCLAIMER: (c)2000 Jeff Molofee

	If you plan to put this program on your web page or a cdrom of
	any sort, let me know via email, I'm curious to see where
	it ends up :)
