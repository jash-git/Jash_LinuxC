OpenGL Tutorial #31.

Project Name: Model Loading Tutorial.

Project Description:  Learn How To Load Fully Texture Mapped Models Created With Milkshape.

Authors Name: Brett Porter

Authors Web Site: www.geocities.com/brettporter/programming
NeHe Productions Web Site: nehe.gamedev.net

COPYRIGHT AND DISCLAIMER: (c)2000 Jeff Molofee

	If you plan to put this program on your web page or a cdrom of
	any sort, let me know via email, I'm curious to see where
	it ends up :)
