OpenGL Tutorial #39.

Project Name: Physics

Project Description: A simple physical simulation engine.

Authors Name:	Erkin Tunca

Hosted Web Site: http://nehe.gamedev.net

COPYRIGHT AND DISCLAIMER: (c)2002 Jeff Molofee

       If you plan to put this program on your web page or a cdrom of
       any sort, let me know via email, I'm curious to see where
       it ends up :)

       If you use the code for your own projects please give the author credit,
       or mention his web site somewhere in your program or it's docs.
