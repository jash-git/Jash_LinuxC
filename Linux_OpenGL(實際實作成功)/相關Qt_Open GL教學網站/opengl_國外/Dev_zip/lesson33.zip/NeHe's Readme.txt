OpenGL Tutorial #33.

Project Name: Fancy TGA Loading.

Project Description:  A Simple Tutorial To Demonstrate Loading Uncompressed / Compressed Textures.

Authors Name: Evan "terminate" Pipho & Jeff Molofee (Graphics)

NeHe Productions Web Site: nehe.gamedev.net

COPYRIGHT AND DISCLAIMER: (c)2001 Jeff Molofee

	If you plan to put this program on your web page or a cdrom of
	any sort, let me know via email, I'm curious to see where
	it ends up :)
