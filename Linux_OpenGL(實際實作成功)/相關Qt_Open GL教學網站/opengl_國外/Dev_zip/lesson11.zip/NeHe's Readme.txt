OpenGL Tutorial #11.

Project Name: bosco's Wave-Thingy

Project Description: Moving Texture Map.

Authors Name: bosco <bosco4@home.com> & Jeff Molofee (aka NeHe)
	      
Web Site: nehe.gamedev.net (NeHe Productions)

COPYRIGHT AND DISCLAIMER: (c)2000 Jeff Molofee / bosco

	If you plan to put this program on your web page or a cdrom of
	any sort, let me know via email, I'm curious to see where
	it ends up :)

        If you use the code for your own projects please give me credit,
        or mention my web site somewhere in your program or it's docs.

Thanks to NeHe for making this all possible.

Greets: MachineCraig, Serenitee, and MWalker
