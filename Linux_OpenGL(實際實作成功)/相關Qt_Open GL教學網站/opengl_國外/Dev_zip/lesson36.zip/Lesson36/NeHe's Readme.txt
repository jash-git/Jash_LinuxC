OpenGL Tutorial #36.

Project Name: Radial Blur & Rendering To A Texture

Project Description: How To Create A Radial Blur Effect

Authors Name:	Dario Corno (rIo) / Jeff Molofee (NeHe)

Authors Web Site: http://www.spinningkids.org/rio
                  http://nehe.gamedev.net

COPYRIGHT AND DISCLAIMER: (c)2001 Jeff Molofee

       If you plan to put this program on your web page or a cdrom of
       any sort, let me know via email, I'm curious to see where
       it ends up :)

       If you use the code for your own projects please give the author credit,
       or mention his web site somewhere in your program or it's docs.
