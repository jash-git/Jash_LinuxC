OpenGL Tutorial #34.

Project Name: Height Mapping

Project Description: Using A .RAW Image To Create A Landscape Using Height Mapping.

Authors Name:	Ben Humphrey (aka DigiBen)

Authors Web Site: www.GameTutorials.com

NeHe Productions: nehe.gamedev.net

COPYRIGHT AND DISCLAIMER: (c)2001 Jeff Molofee

	If you plan to put this program on your web page or a cdrom of
	any sort, let me know via email, I'm curious to see where
	it ends up :)

        If you use the code for your own projects please give me credit,
        or mention my web site somewhere in your program or it's docs.
