#ifndef	STRING_H
#define	STRING_H

extern const void * String;

#endif
