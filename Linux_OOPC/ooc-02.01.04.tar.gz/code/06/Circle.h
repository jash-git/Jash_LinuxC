#ifndef	CIRCLE_H
#define	CIRCLE_H

#include "Point.h"

extern const void * Circle;		/* new(Circle, x, y, rad) */

void initCircle (void);

#endif
