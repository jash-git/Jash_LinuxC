import java.net.DatagramPacket;

// PacketListenerInterface used by threads that need to
// be notified of datagram packet receipt. A single
// interface function packetReceived passes the packet
// information to the thread requiring the information.

public interface PacketListenerInterface {
  public void packetReceived(DatagramPacket packet);
}
