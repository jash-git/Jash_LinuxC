#include "./php.h"
#include "./internal_functions.h"
#include "./myfun.h"
void myadd(INTERNAL_FUNCTIONS_PARAMETERS){
	printf("\nhello world\n");
}
