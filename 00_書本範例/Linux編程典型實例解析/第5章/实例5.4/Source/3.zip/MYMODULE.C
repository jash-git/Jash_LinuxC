#include "./phpdl.h"
DLEXPORT void hello_world(INTERNAL_FUNCTION_PARAMETERS);
function_entry mymodule_functions[] = {
	{ "hello_world", hello_world , NULL },
	{ NULL , NULL , NULL }
};

php3_module_entry mymodule_module_entry = {
"mymodule",mymodule_functions,
NULL , NULL , NULL , NULL , NULL ,STANDARD_MODULE_PROPERTIES
};

#if COMPILE_DL
DLEXPORT php3_module_entry *get_module(void){
	return	&mymodule_module_entry;
}
#endif


DLEXPORT void hello_world (INTERNAL_FUNCTION_PARAMETERS) {
	printf("hello world!\n");
}
