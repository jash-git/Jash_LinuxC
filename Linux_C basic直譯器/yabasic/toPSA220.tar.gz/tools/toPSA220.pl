#!/usr/bin/perl 

use Getopt::Long;
use strict;
use Carp;

$|=1;
my $help;
my $repeat=1;
my $all="sort";

sub sys(@);

if (!GetOptions("help"=>\$help,"all=s"=>\$all,"repear"=>\$repeat) || (@ARGV) || $help || $all!~/^sort|ask$/) {
  print <<EOUSAGE;
    
  usage: toPSA220.pl  [-help] [-all sort|ask]
      
      Create playlists for Phillips/Nike MP3 PSA 220/250 Player, based on the
      directory structure in _system/media/audio.

      The files and subdirectories in this directory will have their names 
      modified in order to shorten them (e.g. spaces removed, common chars 
      at both ends deleted). This might not be, what you expect.

      Version 2.72 from November 22, 2005

      This program might be distributed and modified under the terms 
      of the Gnu Public License.

      Copyright 2004,2005 by Marc-Oliver Ihm


  options:    

      -help     : Display this message.
      -all sort : Take the existing playlists in alphabetical order
                   to form the playlist ALL. This is the default.
      -all ask  : Ask the user, in which order the existing playlists
                   should go into ALL-
      -repeat   : Number of times, the Text between playlists in
                   Playlist ALL should be repeated (default: 1).

  Some remarks concerning the playlist ALL:

     The special playlist ALL will be constructed by concatenating either:
       -- All playlists in alphabetcial order, or
       -- Only selected playlists in specified order,
     as specified by the option -all.

     The contents, sequence and duration of the playlists 
     within ALL are written to the file all.txt within the
     audio directory.

     Optionally you may create a directory _Numbers as a subdirectory 
     of audio, and place files named Playlist.mp3, 1.mp3, 2.mp3 ...
     therein. These files would contain the spoken words "Playlist", 
     "one", "two" and so on, and may be obtained from 
     http://www.naturalvoices.att.com/demos/ or similar sites.
     These files will then be used to mark the beginning of each
     seperate playlist within the playlist ALL.
 
EOUSAGE
  ;
  exit;
}

require MP3Info;

my $sqlhead=<<EOHEAD;
CREATE TABLE albumTable(iAlbumId INTEGER PRIMARY KEY, cAlbumTitle VARCHAR(100));
CREATE TABLE artistTable(iArtistId INTEGER PRIMARY KEY, cArtistName VARCHAR(100));
CREATE TABLE dirTable(iDirId INTEGER PRIMARY KEY, cDirName VARCHAR(260),iParentDirId INTEGER);
CREATE TABLE genreTable(iGenreId INTEGER PRIMARY KEY, cGenreName VARCHAR(50));
CREATE TABLE playlistTable(iPlaylistId INTEGER PRIMARY KEY,cPlaylistName VARCHAR(100), cFileName VARCHAR(260),iDirId INTEGER);
CREATE TABLE playsongTable(iPlaysongId INTEGER PRIMARY KEY,iPlaylistId INTEGER, iOrderNr INTEGER,iSongId INTEGER);
CREATE TABLE songTable (iSongId INTEGER PRIMARY KEY,cSongTitle VARCHAR(100),iArtistId INTEGER,iAlbumId INTEGER,iTrackNr INT8,iTrackLength INT16,iNrPlayed INT16,cFileName VARCHAR(260),iDirId INTEGER,iYear INT8,iGenreId INTEGER,iBitRate INTEGER,iSampleRate INTEGER,iFileSize INTEGER,iMediaType INTEGER);
EOHEAD
;

my $sqltail=<<EOTAIL;
CREATE INDEX album_cAlbumTitle ON albumTable (cAlbumTitle);
CREATE INDEX artist_cArtistName ON artistTable (cArtistName);
CREATE INDEX dir_cDirName ON dirTable (cDirName);
CREATE INDEX dir_iParentDirId ON dirTable (iParentDirId);
CREATE INDEX genre_cGenreName ON genreTable (cGenreName);
CREATE INDEX playlist_cPlaylistName ON playlistTable (cPlaylistName);
CREATE INDEX playsong_iOrderNr ON playsongTable (iOrderNr);
CREATE INDEX playsong_iPlaylistId ON playsongTable (iPlaylistId);
CREATE INDEX playsong_iSongId ON playsongTable (iSongId);
CREATE INDEX song_cFileName ON songTable (cFileName);
CREATE INDEX song_cSongTitle ON songTable (cSongTitle);
CREATE INDEX song_iAlbumId ON songTable (iAlbumId);
CREATE INDEX song_iArtistId ON songTable (iArtistId);
CREATE INDEX song_iDirId ON songTable (iDirId);
CREATE INDEX song_iGenre ON songTable (iGenreId);
CREATE INDEX song_iTrackNr ON songTable (iTrackNr);
EOTAIL
;

my $tools=$0;
$tools=~s/[^\/]*\/?$//;
$tools=$ENV{PWD} if $tools eq "./";
die "Need to run from within tools directory (not $tools) !\n" unless $tools=~/\/tools/;
(my $base=$tools)=~s/\/tools\/?//;
my $audio="$base/_system/media/audio";
print "(Working in $audio)\n";
$ENV{LD_LIBRARY_PATH}="$tools:$ENV{LD_LIBRARY_PATH}";
sys "cp $0 /tmp";

print "\nExtracting zip-files ...\n";
my @zip=glob "$audio/*.zip";
for my $zip (@zip) {
  print "  $zip ...\n";
  my @mp3;
  open UNZIP,"unzip -l $zip |" or die "Could not start unzip: $!\n";
  <UNZIP> for 1..3;
  while (<UNZIP>) {
    my $file=(split " ",$_)[-1];
    next unless $file=~/\.mp3$/;
    print "    contains $file\n";
    push @mp3,$file;
  }
  my @temp;
  my %temp2short;
  for my $mp3 (@mp3) {
    my $temp=qx(mktemp /tmp/PSA.XXXXXX);
    chomp $temp;
    my $short=$mp3;
    $short=~s/.*\///;
    $temp2short{$temp}=$short;
    print "    unzip $mp3\n";
    sys "unzip -p $zip $mp3 >$temp";
  }
  sys "rm $zip";
  my $dir=$zip;
  $dir=~s/\.zip$//;
  sys "mkdir $dir";
  print "  moving to $dir:\n";
  for my $temp (keys %temp2short) {
    sys "mv $temp $dir/$temp2short{$temp}";
    print "    $temp as $temp2short{$temp}\n";
  }
}
print "done.\n";


print "\nCleaning up directory- and filenames ...\n";
for my $dir (grep -d, glob "$audio/*") {
    system "rmdir \"$dir\" >/dev/null 2>&1";
}
for my $dir (grep -d, glob "$audio/*") {
  next if $dir eq "$audio/_Numbers";
  my $count=1;
  tidy_tree($dir,\$count);
}
print "done.\n";


print "\nCreating playlists ...\n";
my $dirs={};
for my $dir (grep -d, glob "$audio/*") {
  collect_dirs($dirs,$dir);
}
print "\ndone.\n";


print "\nCreating SQL-script ...\n";

my $sqlite="$tools/sqlite";
my $sql="$tools/psa.sql";
open SQL,">$sql" or die "Could not write to $sql: $!\n";
print SQL $sqlhead;
my %playlist_secs;
my %playlist_bytes;
my $playlistid=0;
my $dirid=2;
my $songid=0;
my $playsongid=0;

my %dirids;
my $rest;
print SQL "INSERT INTO dirTable VALUES(1,'C:',-559030611);\n";
for (qw(_system media audio)) {
  my $parent=$base.$rest;
  $rest.="/$_";
  $dirids{$base.$rest}={id=>$dirid,parent=>$parent};
  print SQL "INSERT INTO dirTable VALUES($dirid,'$_',".($dirid-1).");\n";
  $dirid++;
}
for my $dir (sort keys %$dirs) {
  my $currdir=$base;
  my @parts=split "/",substr($dir,length($base)+1);;
  for my $part (@parts) {
    my $parent=$currdir;
    $currdir.="/$part";
    next if $dirids{$currdir};
    $dirids{$currdir}={id=>$dirid,parent=>$parent};
    print SQL "INSERT INTO dirTable VALUES($dirid,'$part',$dirids{$parent}->{id});\n";  
    $dirid++;
  }
}

my %all;
my %all_used;
my %numbers;
for my $dir (sort keys %$dirs) {
  my $playlist=substr($dir,length($audio)+1);
  $playlist=~s/\///g;
  unless ($playlist eq "_Numbers") {
    $playlistid++;
    print SQL "INSERT INTO albumTable VALUES($playlistid,'$playlist');\n";
    print SQL "INSERT INTO artistTable VALUES($playlistid,'$playlist');\n";
    print SQL "INSERT INTO genreTable VALUES($playlistid,'$playlist');\n";
    print SQL "INSERT INTO playlistTable VALUES($playlistid,'$playlist',NULL,NULL);\n";
  }
  my $position=0;
  for my $file (sort @{$dirs->{$dir}}) {
    $songid++;
    $playsongid++;
    $position++;
    my $mp3info=MP3::Info::get_mp3info($file) or die "Could not figure out duration of $file: $!";
    my $duration=int($mp3info->{SECS});
    $duration=1 if $duration<1;
    $playlist_secs{$playlist}+=$duration;
    $playlist_bytes{$playlist}+= -s($file);
    
    print SQL "INSERT INTO playsongTable VALUES($playsongid,$playlistid,$position,$songid);\n" unless $playlist eq "_Numbers";
    $file=~/^(.*)\/([^\/\.]*)\.([^\/\.]*)$/ or die "Could not parse filename '$file'";
    my ($path,$short,$ending)=($1,$2,$3);
    print SQL "INSERT INTO songTable VALUES($songid,'$short',$playlistid,$playlistid,$songid,$duration,1,'$short.$ending',".$dirids{$path}->{id}.",2005,1,0,0,0,3);\n";
    if ($playlist eq "_Numbers") {
      $numbers{$short}=$songid;
    } else {
      push @{$all{$playlist}},$songid;
    }
  }
}
print "done.\n";

print "\nSize and Duration of Individual playlists:\n\n";
my $totbytes=0;
my $totsec=0;
my $allbytes=0;
my $allsec=0;
my $maxlen=length("Overall");
my $allfile="$audio/all.txt";

for my $playlist (sort keys %all) {
  $maxlen=length($playlist) if length($playlist)>$maxlen;
}
my $i=1;
my %playlist2num;
for my $playlist (sort keys %all) {
  $playlist2num{$playlist}=$i;
  print "\t",sprintf("%3d ",$i++),pl_info($maxlen,$playlist,$playlist_secs{$playlist},$playlist_bytes{$playlist}),"\n\n";
  $totbytes+=$playlist_bytes{$playlist};
  $totsec+=$playlist_secs{$playlist};
  if ($all_used{$playlist}) {
    $allbytes+=$playlist_bytes{$playlist};
    $allsec+=$playlist_secs{$playlist};
  }
}
print "\t    ",pl_info($maxlen,"Overall",$totsec,$totbytes),"\n\n";
print "done.\n";

print "\nCreating playlist ALL ...\n";
$playlistid++;
print SQL "INSERT INTO playlistTable VALUES($playlistid,'ALL',NULL,NULL);\n";
my @all_with_order;
my @all_sorted=sort keys %all;
my $thisinput;
if ($all eq "sort") {
  @all_with_order=sort keys %all;
  %all_used=%all;
  $thisinput="option sort";
} else {
  my $num_lists=@all_sorted;
  my $list;
  my $lastinput="unknown";
  open ALLCONT,$allfile;
  my $line=<ALLCONT>;
  if ($line=~/^\(Generated from input '(.*)'\)\s*$/) {
    my @li=split " ",$1;
    $lastinput="";
    my $newlast=1;
    for my $li (@li) {
      $lastinput.=" " if $lastinput && @li>9;
      if ($playlist2num{$li}) {
	$lastinput.=$playlist2num{$li};
      } else {
	$lastinput.=" $li ";
      }
    }
    $lastinput=~s/\s*$//;
    $lastinput=~s/^\s*//;
    $lastinput=~s/\s+/ /g;
  }
  print "\nPrevious input was '$lastinput'\n";
  print "\nPlease enter the numbers you want to hear first in playlist ALL.\n";
  if ($num_lists<=9) {
    print "You may enter them without spaces (e.g. 14279 ...),\nor just press RETURN to use them in this order.\n";
    print "\nYour input: ";
    $list=<STDIN>;
    chomp $list;
    $list=~s/(\d)/$1 /g;
  } else {
    print "Seperate them with spaces (e.g. 1 3 12 2 ...),\nor just press RETURN to use them in this order.\n";
    print "\nYour input: ";
    $list=<STDIN>;
    chomp $list;
  }
  for (split " ",$list) {
    die "Your input is invalid: $_ is not within in 1 .. $num_lists !\n" if $_<1 || $_>$num_lists;
    push @all_with_order,$all_sorted[$_-1];
    $all_used{$all_sorted[$_-1]}=1;
  }
  unless(@all_with_order) {
    @all_with_order=@all_sorted;
    %all_used=%all;
    $thisinput="RETURN";
  }
}

for my $playlist (keys %all_used) {
  $allbytes+=$playlist_bytes{$playlist};
  $allsec+=$playlist_secs{$playlist};
}
print "\nPlaylist ",pl_info(4,"ALL",$allsec,$allbytes),"\n";
for my $playlist (@all_sorted) {
  next if $all_used{$playlist};
  push @all_with_order,$playlist;
  $allbytes+=$playlist_bytes{$playlist};
  $allsec+=$playlist_secs{$playlist};
}
$thisinput=join " ",@all_with_order unless $thisinput;

open ALLCONT,">$allfile" or die "Could not write $allfile: $!\n";
print ALLCONT "(Generated from input '$thisinput')\n\n";
print ALLCONT "\n Number ",(" " x ($maxlen-4))," Title ","       Size Duration   Played     Left\n";
print ALLCONT ("=" x ($maxlen+49)),"\n";
my $position=0;
my $uptohere=0;
my $untilend=$allsec;
my $count;
for my $playlist (@all_with_order) {
  $position++;
  $count++;
  if ($numbers{"Playlist"} && $numbers{$count}) {
    for (1 .. $repeat) {
      $playsongid++;
      print SQL "INSERT INTO playsongTable VALUES($playsongid,$playlistid,$position,$numbers{Playlist});\n";
      $position++;
      $playsongid++;
      print SQL "INSERT INTO playsongTable VALUES($playsongid,$playlistid,$position,$numbers{$count});\n";
      $position++;
    }
  }
  my $secs=$playlist_secs{$playlist};
  print ALLCONT sprintf("    %3d",$count),"  ",pl_info($maxlen,$playlist,$secs,$playlist_bytes{$playlist},1),"  ",format_time($uptohere),"  ",format_time($untilend),"\n";
  $uptohere+=$secs;
  $untilend-=$secs;
  for my $songid (@{$all{$playlist}}) {
    $playsongid++;
    print SQL "INSERT INTO playsongTable VALUES($playsongid,$playlistid,$position,$songid);\n";
  }
}
print ALLCONT "\n";
close ALLCONT;

print SQL $sqltail;
close SQL;

my $db;
$db=qx(mktemp /tmp/PSA.XXXXXX);
chomp $db;

print "\nCreating Database $db ...\n";
$db=~/^(.*)\/([^\/]*)$/ or die "Could not parse path '$db'";
my ($wdir,$short)=($1,$2);
open SQLITE,"cd $wdir; $sqlite $short <<EOF\n.read $sql\n.exit\nEOF\n |" or die "Could not start sqlite";
my $errors=0;
while (<SQLITE>) {
  print "  >>  $_";
  $errors++ if /error/i;
}
die "Error while executing '$sqlite $db <<.read $sql': See above !" if $errors;
print "done.\n";

print "\nCopying database ... ";
sys "mv $db $audio/MyDB";
print "done.\n";
print "\nProgram done.\n\n";


sub pl_info {
  my $max=shift;
  my $playlist=shift;
  my $secs=shift;
  my $bytes=shift;
  my $comma=",";
  my $colon=":";
  $comma=$colon=" " if shift;

  return substr((" " x ($max+1)).$playlist,-$max-1).
    " $colon  ".sprintf("%5d MB",int(0.5+$bytes/1000/1000)).
      "$comma ".format_time($secs);
}


sub format_time {
  my $secs=shift;

  my $tothours=sprintf("%2d",int($secs/3600));
  my $totminutes;
  my $totminutes=sprintf "%02d",int(($secs-3600*$tothours)/60);
  my $totseconds=sprintf "%02d",$secs-3600*$tothours-60*$totminutes;

  if ($tothours>0) {
    return "$tothours:$totminutes:$totseconds";
  } else {
    $totminutes=~s/0/ /g;
    if ($totminutes>0) {
      return "   $totminutes:$totseconds";
    } else {  
      $totseconds=~s/0/ /g;
      return "      $totseconds";
    }
  }
}


sub collect_dirs {
  my $dirs=shift;
  my $path=shift;

  my $first;
  my @short;
  for my $mp3 (grep -f, glob "$path/*.mp3") {
    (my $short=$mp3)=~s/.*\///;
    push @short,$short;
    push @{$dirs->{$path}},$mp3;
  }

  if (@short) {
    my @sorted=sort {length($a)<=>length($b)} @short;
    my $i=@sorted-1;
    my $len=100;
    do {
      $len=length($sorted[$i]);
      $i--;
      $i=0 if $i/@sorted<0.8 && @sorted>10;
      $i=0 if @sorted-$i>3;
    } while ($i && $len>10);
    $len+=2;
    unshift @short,"  ".substr($path,length($audio)+1)." : ";
    print "\n";
    my $cols=80;
    my $out=qx(stty -a 2>&1);
    $cols=$1 if $out=~/columns\s*=?\s*(\d+)/mi;
    my $col=0;
    my $first=1;
    for (sort @short) {
      my $l=$len*(1+int((length($_)/$len)));
      my $t;
      if ($first) {
	$t=substr($_.(" " x $l),0,$l)."    ";
      } else {
	$t=substr((" " x $l).$_,-$l);
      }
      $first=0;
      if ($col+length($t)>=$cols) {
	print "\n    ";
	$col=4;
      }
      print $t;
      $col+=length($t);
    }
    print "\n";
  }

  for my $dir (grep -d, glob "$path/*") {
    collect_dirs($dirs,$dir);
  }
}


sub find_common {
  return ("","",0) if @_<2;
  my @files=map {/([^\/]+)$/; $1 || $_} @_;
  my $chead=@files[0];
  my $ctail=$chead;
  my $ndigits=100;
  for (@files) {
    while (!/^$chead/) {
      substr($chead,-1)="";
    }
  }
  for (@files) {
    while (!/$ctail$/) {
      substr($ctail,0,1)="";
    }
  }
  for (1 .. 2) {
    substr($chead,-1)="" if substr($chead,-1)=~/\d/;
  }
  for (@files) {
    while ($ndigits && /$chead.*\d{$ndigits}.*$ctail/) {
      $ndigits--;
    }
  }
  $ctail=~s/.mp3$//;
  return $chead,$ctail,$ndigits+0;
}


sub tidy_tree {
  my $count=pop;
  my $full=shift;
  my $chead=shift;
  my $ctail=shift;
  my $ndigits=shift;
  my $width=shift;
  my $tidy;
  $tidy=tidy_name($full,$chead,$ctail,$ndigits,$width,$count);
  if (-d $full) {
    my $cparts="$full/cache_for_common_parts.txt";
    my @entries=glob "$full/*.mp3";
    my ($chead,$ctail,$ndigits);
    if (open COMMON,$cparts) {
      while(<COMMON>) {
	s/#.*//;
	$chead=$1 if /^\s*common_head\s*= (.+)$/;
	$ctail=$1 if /^\s*common_tail\s*= (.+)$/;
	$ndigits=$1 if /^\s*length_of_common_digits\s*=\s*(\d+)\s*$/;
      }
      close COMMON;
    } else {
      ($chead,$ctail,$ndigits)=find_common(@entries);
      if (open COMMON,">$cparts") {
	print COMMON "###\n###  Created on ".scalar(localtime)."\n###\n\n";
	print COMMON " common_head             = $chead\n";
	print COMMON " common_tail             = $ctail\n";
	print COMMON " length_of_common_digits = $ndigits\n";
	print COMMON "\n#\n# Based on these filenames:\n#\n";
	for (sort @entries) {
	  print COMMON "#     $_\n";
	}
	print COMMON "#\n# (end of list)\n#\n";
	close COMMON;
      }
    }
    my $newcount=1;
    for my $dir (@entries,grep(-d,glob "$full/*")) {
      tidy_tree($dir,$chead,$ctail,$ndigits,length scalar(@entries),\$newcount);
    }
  }
  return if $full eq $tidy;
  my $short=$tidy;
  $short=~s/.*\///;
  sys "mv \"$full\" $tidy-temp";
  sys "mv $tidy-temp $tidy"
}


sub tidy_name {
  my $full=shift;
  my $chead=shift;
  my $ctail=shift;
  my $ndigits=shift;
  my $width=shift;
  my $count=shift;

  my $entry=$full;
  $entry=~s/.*\///;
  my $path=$full;
  $path=~s/[^\/]+$//;
  my $plen=length($full)-length($entry);
  my ($pre,$dot,$post);
  if ($entry=~/^(.*)(\.)([^\.]*)$/) {
    ($pre,$dot,$post)=($1,$2,$3);
  } else {
    $pre=$entry;
  }
  $pre=~s/^$chead//;
  $pre=~s/$ctail$//;
  $pre=ucfirst($pre);
  $pre=~s/_|-/ /g;
  $pre=~s/[^\sa-zA-z0-9]//g;
  while ($pre=~/^(.*?)\s(..*)$/) {
    $pre=$1.ucfirst(lc($2));
  }
  $pre=~s/\s+//g;
  if ($ndigits>3) {
    if ($pre=~/^(.*?)(\d{$ndigits})(.*)$/) {
      $pre=$1.sprintf("%0${width}d",$$count);
      $pre.="-$3" if $3;
      $$count++;
    }
  }
  
  return "$path$pre$dot$post";
}

 
sub sys (@) {
  my $command=shift;
  my @out;
  open COMMAND,"$command 2>&1 |" or die "Could not start command '$command' : $!\n";
  while (<COMMAND>) {
    push @out,"  >>  $_";
  }
  close COMMAND;
  croak "\nError while executing: '$command' :\n",@out if $?;
}
