This directory contains the perl script 

     toPSA220.pl

,which is intended for the Nike/Philips MP3-Player PSA 220 (and 250).

The script generates playlists for a set of mp3-files and stores them 
within the players internal database. The mp3-files must already be present 
within the directory _system/media/audio.

See the file INSTALL.txt for installation instructions.

Invoke 

         toPSA220.pl --help

for hints on how to use the script.

You should cd into the directory tools before invoking toPSA220.pl.
If this is inconvenient for you you may write a shell script or a makefile, 
that first changes directory to tools and then invokes the script.

toPSA220.pl uses the program sqlite, which is free software (as well as toPSA220.pl itself).

Many thanks to the authors of sqlite (which is the internal database of the
player) and many thanks to Nike/Philips, who created such a nice device, especially
for the needs of runners like me ! 

This program might be distributed under the terms of the GPL.

Copyright 2004,2005 by Marc-Oliver Ihm, ihm@yabasic.de

