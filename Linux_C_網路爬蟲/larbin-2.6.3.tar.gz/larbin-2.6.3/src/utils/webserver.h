// Larbin
// Sebastien Ailleret
// 07-03-00 -> 17-03-02

#ifndef WEBSERVER_H
#define WEBSERVER_H

#ifndef NOWEBSERVER
void *startWebserver (void *none);
#endif // NOWEBSERVER

#endif // WEBSERVER_H
