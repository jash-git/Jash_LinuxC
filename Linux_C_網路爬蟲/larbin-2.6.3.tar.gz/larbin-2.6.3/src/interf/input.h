// Larbin
// Sebastien Ailleret
// 03-02-00 -> 22-07-01

#ifndef INPUT_H
#define INPUT_H

#include "global.h"

/** see if there is some input and manage it */
int input ();

/** init everything */
void initInput ();

#endif // INPUT_H
